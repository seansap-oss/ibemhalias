const encoder = new TextEncoder();

const COOKIE_NAME = "ibemhal_admin_session";
const SESSION_HOURS = 8;
const DEFAULT_ADMIN_USERNAME = "admin";

function bytesToBase64Url(bytes: Uint8Array) {
  let binary = "";
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function normalizeIdentifier(value: string) {
  return String(value || "").trim().toLowerCase();
}

export function secureCompare(left: string, right: string) {
  const a = String(left ?? "");
  const b = String(right ?? "");

  if (a.length !== b.length) return false;

  let diff = 0;
  for (let index = 0; index < a.length; index += 1) {
    diff |= a.charCodeAt(index) ^ b.charCodeAt(index);
  }

  return diff === 0;
}

async function sign(value: string, secret: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(value)
  );

  return bytesToBase64Url(new Uint8Array(signature));
}

function getSessionSecret() {
  const configured = process.env.ADMIN_SESSION_SECRET?.trim();
  if (configured) return configured;

  // Keep production usable when ADMIN_PASSWORD is already configured but a
  // separate session secret was not added yet. A dedicated
  // ADMIN_SESSION_SECRET is still recommended and takes precedence.
  const password = process.env.ADMIN_PASSWORD;
  if (password) {
    return `ibemhal-admin-session-v2:${password}`;
  }

  if (process.env.NODE_ENV !== "production") {
    return "ibemhal-local-dev-session-secret-change-before-production";
  }

  throw new Error("ADMIN_LOGIN_NOT_CONFIGURED");
}

export function getAdminCookieName() {
  return COOKIE_NAME;
}

export async function createAdminSessionToken(identity: string) {
  const normalizedIdentity = normalizeIdentifier(identity);
  if (!normalizedIdentity) {
    throw new Error("ADMIN_LOGIN_NOT_CONFIGURED");
  }

  const exp = Date.now() + SESSION_HOURS * 60 * 60 * 1000;
  const payload = `${normalizedIdentity}.${exp}`;
  const signature = await sign(payload, getSessionSecret());

  return `${payload}.${signature}`;
}

export async function verifyAdminSessionToken(token?: string | null) {
  if (!token) return null;

  const parts = token.split(".");
  if (parts.length < 3) return null;

  const signature = parts.pop()!;
  const expRaw = parts.pop()!;
  const identity = parts.join(".");
  const exp = Number(expRaw);

  if (!identity || !Number.isFinite(exp) || exp < Date.now()) {
    return null;
  }

  const payload = `${identity}.${exp}`;
  const expected = await sign(payload, getSessionSecret());

  if (!secureCompare(expected, signature)) {
    return null;
  }

  return {
    email: identity,
    identity,
    exp,
  };
}

export function getAdminCredentials() {
  const email =
    process.env.ADMIN_EMAIL?.trim() ||
    (process.env.NODE_ENV !== "production"
      ? "admin@ibemhal.ias"
      : "");

  const username =
    process.env.ADMIN_USERNAME?.trim() ||
    DEFAULT_ADMIN_USERNAME;

  const password =
    process.env.ADMIN_PASSWORD ||
    (process.env.NODE_ENV !== "production"
      ? "admin@123"
      : "");

  if (!password) {
    throw new Error("ADMIN_LOGIN_NOT_CONFIGURED");
  }

  return {
    email,
    username,
    password,
  };
}

export function adminIdentifierMatches(
  identifier: string,
  admin: ReturnType<typeof getAdminCredentials>
) {
  const normalized = normalizeIdentifier(identifier);
  if (!normalized) return false;

  const allowed = [admin.username, admin.email]
    .map(normalizeIdentifier)
    .filter(Boolean);

  return allowed.includes(normalized);
}

export function getAdminSessionIdentity(
  admin: ReturnType<typeof getAdminCredentials>
) {
  return normalizeIdentifier(admin.email || admin.username);
}
