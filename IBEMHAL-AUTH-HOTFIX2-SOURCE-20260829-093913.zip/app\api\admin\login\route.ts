import { NextRequest, NextResponse } from "next/server";
import {
  adminIdentifierMatches,
  createAdminSessionToken,
  getAdminCookieName,
  getAdminCredentials,
  getAdminSessionIdentity,
  secureCompare,
} from "@/lib/admin-session";

export const dynamic = "force-dynamic";

function noStore(response: NextResponse) {
  response.headers.set(
    "Cache-Control",
    "private, no-store, no-cache, max-age=0, must-revalidate"
  );
  response.headers.set("Pragma", "no-cache");
  return response;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const identifier = String(
      body?.identifier ??
        body?.email ??
        body?.username ??
        ""
    ).trim();

    const password = String(body?.password ?? "");
    const admin = getAdminCredentials();

    if (
      !adminIdentifierMatches(identifier, admin) ||
      !secureCompare(password, admin.password)
    ) {
      return noStore(
        NextResponse.json(
          { error: "Invalid admin ID or password." },
          { status: 401 }
        )
      );
    }

    const identity = getAdminSessionIdentity(admin);
    const token = await createAdminSessionToken(identity);

    const response = NextResponse.json({
      ok: true,
      authenticated: true,
      role: "admin",
      identity,
    });

    response.cookies.set({
      name: getAdminCookieName(),
      value: token,
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 8 * 60 * 60,
    });

    return noStore(response);
  } catch (error: any) {
    const message =
      error?.message === "ADMIN_LOGIN_NOT_CONFIGURED"
        ? "Admin login is not configured on this deployment."
        : "Unable to sign in.";

    const status =
      error?.message === "ADMIN_LOGIN_NOT_CONFIGURED"
        ? 503
        : 500;

    return noStore(
      NextResponse.json(
        { error: message },
        { status }
      )
    );
  }
}
